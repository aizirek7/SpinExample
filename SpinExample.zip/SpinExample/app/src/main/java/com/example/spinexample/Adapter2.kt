package com.example.spinexample

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.spinexample.databinding.RecordItemBinding


class Adapter2(
    private val list: List<Data2>
) : RecyclerView.Adapter<Adapter2.Holder>() {

    inner class Holder(val binding: RecordItemBinding) : RecyclerView.ViewHolder(binding.root) {}

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val binding = RecordItemBinding.inflate(LayoutInflater.from(parent.context))
        val holder = Holder(binding)
        return holder
    }
    
    override fun getItemCount(): Int {
        return list.size
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        holder.binding.apply {
            recordIcon.setImageResource(list[position].icon)
            recordGold.text = list[position].gold
            userName.text = list[position].userName
        }
    }
}


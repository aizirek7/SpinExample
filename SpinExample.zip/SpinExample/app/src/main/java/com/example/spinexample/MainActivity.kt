package com.example.spinexample

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.spinexample.databinding.ActivityMainBinding
import java.util.*
import android.view.View.OnTouchListener
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class MainActivity : AppCompatActivity() {
    private var dataList = mutableListOf<Data>()
    private var list = mutableListOf<Data>()
    private var records = mutableListOf<String>()
    var count = 1
    lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        dataList.add(Data(R.drawable.icon1))
        dataList.add(Data(R.drawable.icon2))
        dataList.add(Data(R.drawable.icon3))
        dataList.add(Data(R.drawable.icon4))
        dataList.add(Data(R.drawable.icon5))
        dataList.add(Data(R.drawable.icon6))
        dataList.add(Data(R.drawable.icon7))
        dataList.add(Data(R.drawable.icon8))
        dataList.add(Data(R.drawable.icon9))
        dataList.add(Data(R.drawable.icon10))

        list.addAll(dataList)
        dataList.addAll(list)
        list.addAll(dataList)
        dataList.addAll(list)
        list.addAll(dataList)
        dataList.addAll(list)
        list.addAll(dataList)
        dataList.addAll(list)
        list.addAll(dataList)
        dataList.addAll(list)
        list.addAll(dataList)

        initAdapter(false)
    }

    fun onClick(v: View?) {
        if(v == binding.minus){
            if (count == 1){
                count == 1
            }
            else{
                count--
                binding.textView.setText(count.toString())
            }
        }
        if(v == binding.plus){
            count++
            binding.textView.setText(count.toString())
        }
        else if (v == binding.spin){
            initAdapter(true)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun initAdapter(boolean: Boolean){
        binding.recyclerView.layoutManager = GridLayoutManager(applicationContext, 5)
        Collections.shuffle(list)
        binding.recyclerView.setOnTouchListener { v, event -> true }
        val adapter = Adapter(list, binding.recyclerView, boolean)
        binding.recyclerView.adapter = adapter
        if (boolean == true){
            binding.textView2.text = random()
            records.add(binding.textView2.text.toString())
            setLists(records as ArrayList<String>)
        }
        else{
            binding.textView2.text = "0"
        }
    }

    private fun random() : String{
        return (0 until 10001).random().toString()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.setting -> setActivity(Record())
            R.id.record -> setActivity(Record())
        }
        return super.onOptionsItemSelected(item)
    }

    private fun record(){

    }


    fun setLists(list : ArrayList<String>){
        val sharedPreferences = getSharedPreferences("sharedPref", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        val gson = Gson()
        val json = gson.toJson(list)
        editor.putString("LIST",json)
        editor.commit()
    }
    fun getList(): ArrayList<String>{
        val sharedPreferences = getSharedPreferences("sharedPref", Context.MODE_PRIVATE)
        val gson = Gson()
        val json = sharedPreferences.getString("LIST",null)
        val type = object : TypeToken<ArrayList<String>>(){}.type
        return gson.fromJson(json,type)
    }

    fun setActivity(activity : Activity){
        val intent = Intent(this, activity::class.java)
        startActivity(intent)
    }
}
package com.example.spinexample

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Record : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_record)
    }
}
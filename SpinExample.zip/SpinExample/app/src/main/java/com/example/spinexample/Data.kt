package com.example.spinexample

data class Data(val icon : Int)

data class Data2(val icon: Int, val userName: String, val gold: String)